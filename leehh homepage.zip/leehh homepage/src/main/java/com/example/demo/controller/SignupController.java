package com.example.demo.controller;

import com.example.demo.dto.MemberDTO;
import com.example.demo.service.Memberservice;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class SignupController {
    //생성자 주입
    private final Memberservice memberservice;

    //회원가입 페이지 출력 요청
    @GetMapping("/member/save")
    public String saveForm(){

        return "signup";
    }

    @PostMapping("/member/save")
    public String signup(@ModelAttribute MemberDTO memberDTO) {
        System.out.println("SignupController.signup");
        System.out.println("memberDTO = " + memberDTO);
        memberservice.signup(memberDTO);
        return "login";
    }

    @GetMapping("/member/login")
    public String loginForm() {

        return "login";
    }

    @PostMapping("/member/login")
    public String login(@ModelAttribute MemberDTO memberDTO, HttpSession session) {
        MemberDTO loginResult = memberservice.login(memberDTO);
        if (loginResult != null) {
            //login success
            session.setAttribute("loginEmail", loginResult.getEmail());
            session.setAttribute("loginName", loginResult.getName());
            return "main";
        } else {
            //login fail
            return "login";
        }
    }
}

